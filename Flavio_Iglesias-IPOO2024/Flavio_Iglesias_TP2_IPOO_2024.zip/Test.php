<?php
    require "TestAdministrativo.php";
    require "TestGerente.php";

    testCreateAdministrativo();
    testGetAttributesTypes();

?>